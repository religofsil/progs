# -*- coding: utf-8 -*-

import pymorphy2, codecs
morph = pymorphy2.MorphAnalyzer()
result=codecs.open('dic_org_normalised.txt', 'w', 'utf-8')
text=codecs.open('dic_org.txt', 'r', 'utf-8')
for line in text:
	for x in line.split(' ')[:-1]:
		result.write(morph.parse(x)[0].normal_form+' ')
	result.write(morph.parse(line.split(' ')[-1])[0].normal_form+'\n')
