#encoding "utf-8"

OrgDescr -> AnyWord<kwtype="org_descr">;

Org -> OrgDescr interp(Object.Descr) AnyWord<h-reg1> interp(Object.Name; Object.Type="ORG");
Org -> AnyWord<kwtype="org_names"> interp(Object.Name::not_norm; Object.Type="ORG");
OOO -> 'ООО' | 'ОАО' | 'ЗАО' | 'ТОО' | 'ГУП' | 'РИА';
Org -> OOO AnyWord interp(Object.Name; Object.Type="ORG");
