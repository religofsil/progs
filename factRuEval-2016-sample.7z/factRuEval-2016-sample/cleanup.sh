rm *.bin
rm PrettyOutput.html
rm rules.txt
rm tree.txt
rm facts/*
